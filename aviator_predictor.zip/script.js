const roundStatus = document.getElementById("roundStatus");
const roundInfo = document.getElementById("roundInfo");
const historyList = document.getElementById("historyList");
const notification = document.getElementById("notification");
let timerInterval;

// Countdown Timer and Status Update
function startTimer(seconds) {
    let timeLeft = seconds;
    timerInterval = setInterval(() => {
        timeLeft -= 1;
        roundInfo.textContent = \`Next Round in: \${timeLeft}s\`;

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            updateRound();
        }
    }, 1000);
}

// Update Round Status
function updateRound() {
    roundStatus.textContent = "Round Active!";
    roundInfo.textContent = "Predicting...";
    notification.textContent = "New round started!";
    notification.style.display = "block";

    // Add round history after a delay
    setTimeout(() => {
        const newHistory = document.createElement("li");
        newHistory.textContent = \`Round completed at \${new Date().toLocaleTimeString()}\`;
        historyList.appendChild(newHistory);

        notification.style.display = "none";
        startTimer(5); // Reset timer for the next round
    }, 3000);
}

// Event Listeners for Buttons
document.getElementById("startPrediction").addEventListener("click", () => {
    updateRound();
});

document.getElementById("stopPrediction").addEventListener("click", () => {
    clearInterval(timerInterval);
    roundInfo.textContent = "Prediction Stopped";
    roundStatus.textContent = "Round Inactive";
});
