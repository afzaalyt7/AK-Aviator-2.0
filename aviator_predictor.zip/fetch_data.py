
from flask import Flask, jsonify
import requests

app = Flask(__name__)

# Updated API endpoint and key
API_ENDPOINT = "https://bet7k-aviator-api.p.rapidapi.com/bet7k-aviator-latest"
API_KEY = "aa95feeaabmsh9d554c50f51582dp122212jsn874613f90d1a"

@app.route('/get_round_data', methods=['GET'])
def get_round_data():
    try:
        headers = {
            "Authorization": f"Bearer {API_KEY}"
        }
        response = requests.get(API_ENDPOINT, headers=headers)
        data = response.json()

        # Extract and format data as needed
        round_data = {
            "roundStatus": data.get("roundStatus", "waiting"),
            "roundInfo": data.get("roundInfo", "00:00x")
        }
        return jsonify(round_data)
    except Exception as e:
        print("Error fetching data:", e)
        return jsonify({"error": "Failed to fetch data"}), 500

if __name__ == '__main__':
    app.run(debug=True)
